---
name: harmony-ohos-test-tdd
description: 在 HarmonyOS / ArkTS / DevEco Studio 项目中对 ohosTest 进行 TDD 修复的完整工作流。适用于：真实设备运行 Hypium 测试、诊断失败根因、先补测试再修生产代码、最小改动验证、主 App 与测试 HAP 双编译。
agent_created: true
---

# HarmonyOS ohosTest TDD 修复工作流

## 何时使用此 Skill

- 用户在 D:\XingKeyTarot（或任意 HarmonyOS 项目）要求修复某条失败的 Hypium 测试；
- 需要先用真实设备/模拟器运行 `aa test` 拿到失败日志；
- 需要严格按 TDD 执行：先加诊断/正反例测试 → 确认 RED → 最小修改生产代码 → 确认 GREEN；
- 需要同时保证主 App HAP 和测试 HAP 都 `BUILD SUCCESSFUL, ERROR=0`；
- 需要更新验收文档与项目工作日志。

## 前置依赖

- DevEco Studio 已安装，且项目根存在 `.hvigorw-launcher.js`（修复 git bash 小写盘符问题）；
- `hdc.exe` 可用：`D:\HarmonyOS\DevEco Studio\sdk\default\openharmony\toolchains\hdc.exe`；
- 设备已连接：`hdc list targets` 返回非空；
- 项目 `entry/src/ohosTest` 结构已就绪（TestAbility / OpenHarmonyTestRunner / List.test.ets）。

## 完整工作流

### 1. 读取上下文

必须按顺序读取：

1. `AGENTS.md`（项目铁律）；
2. 失败测试用例所在文件（如 `entry/src/ohosTest/ets/test/XinglanRegression.test.ets`）；
3. 被测生产代码（如 `XinglanSpecialIntentResolver.ets`）；
4. 相关枚举/类型定义（如 `XinglanTypes.ets`）；
5. 真实调用链（如 `XinglanChatPage.ets` 中如何消费 `resolveSpecialIntent`）；
6. 语料/回复映射（如 `XinglanCorpus.ets`、`XinglanComposer.ets`）；
7. 回归用例文档（如 `deliverables/防止乱/xinglan_regression_cases.md`）。

### 2. 第一阶段：诊断 RED

不要先改生产代码。只改测试，让失败输出真实信息：

- 使用 `console.info` 打印 `result.intent` 等字段；
- 使用 `expect(result.intent).assertEqual(XinglanSpecialIntent.XXX)` 等精确断言；
- 严禁使用 `any` / `as any` / `@ts-ignore` / 非空断言。

构建并安装测试 HAP：

```powershell
node .hvigorw-launcher.js assembleHap --mode module -p module=entry@ohosTest -p product=default --no-daemon
D:\HarmonyOS\DevEco Studio\sdk\default\openharmony\toolchains\hdc.exe install -r "D:\XingKeyTarot\entry\build\default\outputs\ohosTest\entry-ohosTest-signed.hap"
D:\HarmonyOS\DevEco Studio\sdk\default\openharmony\toolchains\hdc.exe shell aa test -b com.xingkey.tarot -m entry_test -s unittest OpenHarmonyTestRunner -w 120
```

保存完整日志，提取 `OHOS_REPORT_RESULT` 行与失败项 `STATUS_CODE: 1`。

### 3. 根因判定

回答以下问题：

1. 失败输入的真实返回是什么？
2. 期望返回在产品语义中是否合理？
3. 真实返回是否会导致用户可见行为错误？
4. 最小调用链是什么？（输入 → Resolver → 状态机/语料 → 用户可见行为）
5. 属于业务逻辑错误、测试期望过窄、还是规范冲突？

### 4. 第二阶段：补全 TDD 测试

根据根因增加：

- 失败原用例收紧为精确断言；
- 正例：至少覆盖 3-5 条应返回目标意图的输入；
- 反例：至少覆盖 5-6 条不应被误识别为目标意图的输入；
- 每个测试独立断言，不使用宽泛条件。

再次运行，确认 RED：新增正例失败，反例通过，总数增加。

### 5. 第三阶段：最小生产修复

仅修改必要文件：

- 如果是意图缺失：在 Resolver 中新增检测函数，并调整优先级；
- 如果是语料缺失：在 `XinglanCorpus.ets` 新增专用语料池；
- 如果是回复映射缺失：在 `XinglanComposer.ets` 的 `poolMap` 注册；
- 不修改状态机、不修改其他测试期望、不扩大重构范围。

### 6. 第四阶段：验证 GREEN

重新构建测试 HAP，运行全部测试，确认：

- 原失败项 PASS；
- 新增正例 PASS；
- 新增反例 PASS；
- 其他关键安全/边界用例未回归；
- `OHOS_REPORT_RESULT` 中 `Failure: 0`。

### 7. 第五阶段：主 App 编译

运行：

```powershell
node .hvigorw-launcher.js assembleHap --mode module -p module=entry@default -p product=default --no-daemon
```

目标：`BUILD SUCCESSFUL, ERROR=0`。

### 8. 文档与记忆

更新：

- `deliverables/v2_release_candidate_acceptance_report.md`（状态、修复记录、测试命令、结果）；
- `deliverables/xinglan_regression_automation_matrix.md`（用例层级、执行状态、统计）；
- `D:\XingKeyTarot\.workbuddy\memory\YYYY-MM-DD.md`（当日工作日志）。

状态只能更新到 `AUTO_VERIFIED_PARTIAL`，不得更新为 `AUTO_VERIFIED` 或 `RC_ACCEPTED`，除非原始 42 条回归用例全部编写并执行通过。

## 关键命令速查

| 目的 | 命令 |
|---|---|
| 构建测试 HAP | `node .hvigorw-launcher.js assembleHap --mode module -p module=entry@ohosTest -p product=default --no-daemon` |
| 构建主 App HAP | `node .hvigorw-launcher.js assembleHap --mode module -p module=entry@default -p product=default --no-daemon` |
| 安装测试 HAP | `hdc.exe install -r "...\entry-ohosTest-signed.hap"` |
| 运行全部测试 | `hdc.exe shell aa test -b com.xingkey.tarot -m entry_test -s unittest OpenHarmonyTestRunner -w 120` |
| 查看设备 | `hdc.exe list targets` |

## 红线

- 禁止用 `any` / `as any` / `@ts-ignore` / 非空断言；
- 禁止先改生产代码再补测试；
- 禁止删除/跳过失败用例、把断言改成恒真、用宽泛条件换全绿；
- 禁止修改状态机/路由/主页面/核心数据/BGM 等无关系统；
- 禁止把测试期望放宽为包含错误行为。
